export interface Summary {
  page: string;
  total: string;
  pages: string;
}