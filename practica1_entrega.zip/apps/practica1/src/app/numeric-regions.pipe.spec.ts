import { NumericRegionsPipe } from './numeric-regions.pipe';

describe('NumericRegionsPipe', () => {
  it('create an instance', () => {
    const pipe = new NumericRegionsPipe();
    expect(pipe).toBeTruthy();
  });
});
